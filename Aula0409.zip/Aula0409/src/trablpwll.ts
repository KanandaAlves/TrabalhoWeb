import fastify from "fastify";

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const app = fastify();


app.get("/estudantes", async() => {
    const estudantes = await prisma.estudantes.findMany();

    return estudantes;
})

app.get("/professores", async() => {
    const professores = await prisma.professores.findMany();

    return professores;
})

app.get("/disciplinas", async() => {
    const disciplinas = await prisma.disciplinas.findMany();

    return disciplinas;

});

app.listen({
    port: 3333,
}).then(() => {
    console.log('HTPP Server running on port 3333')
})









